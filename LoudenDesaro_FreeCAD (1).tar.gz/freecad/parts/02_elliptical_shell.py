# 02_elliptical_shell.py — Louden/Desaro Gymnasium
# Elliptical building shell (curved walls + roof as one form)
# Run: freecadcmd 02_elliptical_shell.py

import FreeCAD as App
import Part
import math

FT = 304.8
IN = 25.4

doc = App.newDocument("Elliptical_Shell")

BW = 100 * FT  # Building width (X axis)
BL = 100 * FT  # Building length (Y axis)
BH = 22 * FT   # Peak height of elliptical arch
THICK = 6 * IN  # Shell thickness

# Create elliptical arch cross-section (half ellipse)
# Semi-major axis (horizontal) = BW/2, semi-minor (vertical) = BH
a = BW / 2.0
b = BH

# Outer ellipse profile points
pts_outer = []
segments = 64
for i in range(segments + 1):
    angle = math.pi * i / segments  # 0 to PI
    x = -a * math.cos(angle)
    z = b * math.sin(angle)
    pts_outer.append(App.Vector(x + a, 0, z))  # Shift so left edge at x=0

# Inner ellipse profile (smaller by THICK)
ai = a - THICK
bi = b - THICK
pts_inner = []
for i in range(segments + 1):
    angle = math.pi * i / segments
    x = -ai * math.cos(angle)
    z = bi * math.sin(angle)
    pts_inner.append(App.Vector(x + a, 0, z))

# Close the cross-section: outer arch -> right bottom -> inner arch reversed -> left bottom
profile_pts = pts_outer + [App.Vector(BW, 0, 0)]
profile_pts += list(reversed(pts_inner))
profile_pts += [App.Vector(0, 0, 0)]

# Create wire and face from profile
wire = Part.makePolygon(profile_pts + [profile_pts[0]])
face = Part.Face(wire)

# Extrude along Y axis (building length)
shell_solid = face.extrude(App.Vector(0, BL, 0))

shell_obj = doc.addObject("Part::Feature", "EllipticalShell")
shell_obj.Shape = shell_solid
shell_obj.ViewObject.ShapeColor = (0.22, 0.30, 0.40)
shell_obj.ViewObject.Transparency = 10

# South end cap (glass facade — thin face)
cap_outer = []
for i in range(segments + 1):
    angle = math.pi * i / segments
    x = -a * math.cos(angle)
    z = b * math.sin(angle)
    cap_outer.append(App.Vector(x + a, 0, z))

cap_wire = Part.makePolygon(cap_outer + [cap_outer[0]])
cap_face = Part.Face(cap_wire)
cap_solid = cap_face.extrude(App.Vector(0, -2 * IN, 0))

south_cap = doc.addObject("Part::Feature", "SouthFacade_Glass")
south_cap.Shape = cap_solid
south_cap.ViewObject.ShapeColor = (0.55, 0.75, 0.85)
south_cap.ViewObject.Transparency = 70

# North end cap (solid metal)
north_cap = doc.addObject("Part::Feature", "NorthWall")
north_cap.Shape = cap_solid.copy()
north_cap.Placement = App.Placement(App.Vector(0, BL, 0), App.Rotation())
north_cap.ViewObject.ShapeColor = (0.18, 0.22, 0.28)

doc.recompute()
doc.saveAs("/tmp/02_elliptical_shell.FCStd")
print("✅ 02_elliptical_shell.FCStd saved")
