# 03_steel_structure.py — Louden/Desaro Gymnasium
# Structural steel ribs (elliptical arches every 20')
# Run: freecadcmd 03_steel_structure.py

import FreeCAD as App
import Part
import math

FT = 304.8
IN = 25.4

doc = App.newDocument("Steel_Structure")

BW = 100 * FT
BL = 100 * FT
BH = 22 * FT
a = BW / 2.0
b = BH

RIB_W = 8 * IN   # Rib flange width
RIB_D = 4 * IN   # Rib depth
SPACING = 20 * FT

for frame in range(6):  # 0', 20', 40', 60', 80', 100'
    y_pos = frame * SPACING
    if y_pos > BL:
        y_pos = BL

    # Create elliptical rib as a swept pipe
    pts = []
    segs = 48
    for i in range(segs + 1):
        angle = math.pi * i / segs
        x = -a * math.cos(angle) + a
        z = b * math.sin(angle)
        pts.append(App.Vector(x, y_pos, z))

    # Make wire from points
    wire = Part.makePolygon(pts)

    # Create rectangular cross-section for sweep
    half_w = RIB_W / 2
    half_d = RIB_D / 2
    # Profile at first point, oriented perpendicular to rib
    p0 = pts[0]
    rect_pts = [
        App.Vector(p0.x - half_d, p0.y - half_w, p0.z),
        App.Vector(p0.x + half_d, p0.y - half_w, p0.z),
        App.Vector(p0.x + half_d, p0.y + half_w, p0.z),
        App.Vector(p0.x - half_d, p0.y + half_w, p0.z),
    ]

    # Simple approach: extrude a box along the arch path using makePipe
    try:
        profile_wire = Part.makePolygon(rect_pts + [rect_pts[0]])
        profile_face = Part.Face(profile_wire)
        rib_solid = wire.makePipe(profile_face)
        rib = doc.addObject("Part::Feature", f"Rib_{frame}")
        rib.Shape = rib_solid
    except:
        # Fallback: approximate with thin boxes along the arch
        for i in range(segs):
            p1 = pts[i]
            p2 = pts[i + 1]
            mid = App.Vector((p1.x+p2.x)/2, (p1.y+p2.y)/2, (p1.z+p2.z)/2)
            seg_len = p1.distanceToPoint(p2)
            seg = doc.addObject("Part::Box", f"RibSeg_{frame}_{i}")
            seg.Length = seg_len
            seg.Width = RIB_W
            seg.Height = RIB_D
            # Calculate angle
            dx = p2.x - p1.x
            dz = p2.z - p1.z
            ang = math.degrees(math.atan2(dz, dx))
            seg.Placement = App.Placement(
                App.Vector(p1.x, y_pos - RIB_W/2, p1.z),
                App.Rotation(App.Vector(0, 1, 0), -ang)
            )
            seg.ViewObject.ShapeColor = (0.35, 0.35, 0.35)

    # Horizontal tie beam at eave height
    tie = doc.addObject("Part::Box", f"TieBeam_{frame}")
    tie.Length = BW
    tie.Width = RIB_W
    tie.Height = RIB_D
    tie.Placement = App.Placement(
        App.Vector(0, y_pos - RIB_W/2, BH * 0.15),
        App.Rotation()
    )
    tie.ViewObject.ShapeColor = (0.35, 0.35, 0.35)

doc.recompute()
doc.saveAs("/tmp/03_steel_structure.FCStd")
print("✅ 03_steel_structure.FCStd saved")
