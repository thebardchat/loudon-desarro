# 07_sc_equipment.py — Louden/Desaro Gymnasium
# Strength & Conditioning equipment on rubber flooring
# Run: freecadcmd 07_sc_equipment.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("SC_Equipment")

BW = 100 * FT
BL = 100 * FT
DIV_X = 60 * FT
SC_X = DIV_X + 6 * IN  # Just past divider wall
SC_W = BW - SC_X - 6 * IN  # ~40' wide

# ---- RUBBER FLOORING ----
floor = doc.addObject("Part::Box", "Rubber_Floor")
floor.Length = SC_W
floor.Width = BL
floor.Height = 0.5 * IN
floor.Placement = App.Placement(App.Vector(SC_X, 0, 0), App.Rotation())
floor.ViewObject.ShapeColor = (0.12, 0.12, 0.14)

# ---- POWER RACKS (5 racks along west wall of S&C) ----
for i in range(5):
    # Uprights (4 posts)
    for dx, dy in [(0, 0), (4*FT, 0), (0, 3.5*FT), (4*FT, 3.5*FT)]:
        post = doc.addObject("Part::Box", f"Rack{i}_Post_{int(dx)}_{int(dy)}")
        post.Length = 3 * IN
        post.Width = 3 * IN
        post.Height = 7.5 * FT
        post.Placement = App.Placement(
            App.Vector(SC_X + 2 * FT + dx, 6 * FT + i * 16 * FT + dy, 0),
            App.Rotation()
        )
        post.ViewObject.ShapeColor = (0.30, 0.30, 0.32)

    # Cross bar (barbell)
    bar = doc.addObject("Part::Box", f"Rack{i}_Bar")
    bar.Length = 7 * FT
    bar.Width = 1.5 * IN
    bar.Height = 1.5 * IN
    bar.Placement = App.Placement(
        App.Vector(SC_X + 0.5 * FT, 6 * FT + i * 16 * FT + 1.5 * FT, 5 * FT),
        App.Rotation()
    )
    bar.ViewObject.ShapeColor = (0.70, 0.70, 0.72)

    # Bench
    bench = doc.addObject("Part::Box", f"Rack{i}_Bench")
    bench.Length = 4 * FT
    bench.Width = 1 * FT
    bench.Height = 18 * IN
    bench.Placement = App.Placement(
        App.Vector(SC_X + 2 * FT, 6 * FT + i * 16 * FT + 1 * FT, 0),
        App.Rotation()
    )
    bench.ViewObject.ShapeColor = (0.20, 0.20, 0.22)

# ---- DUMBBELL RACK (long rack along back/east) ----
db_rack = doc.addObject("Part::Box", "Dumbbell_Rack")
db_rack.Length = 2 * FT
db_rack.Width = 30 * FT
db_rack.Height = 4 * FT
db_rack.Placement = App.Placement(
    App.Vector(BW - 4 * FT, BL / 2 - 15 * FT, 0),
    App.Rotation()
)
db_rack.ViewObject.ShapeColor = (0.35, 0.35, 0.38)

# ---- CABLE MACHINES (3 units, center of S&C) ----
for i in range(3):
    tower = doc.addObject("Part::Box", f"Cable_{i}")
    tower.Length = 3 * FT
    tower.Width = 2.5 * FT
    tower.Height = 8 * FT
    tower.Placement = App.Placement(
        App.Vector(SC_X + SC_W / 2 - 1.5 * FT, 15 * FT + i * 28 * FT, 0),
        App.Rotation()
    )
    tower.ViewObject.ShapeColor = (0.28, 0.28, 0.30)

# ---- ELLIPTICAL MACHINES (6 units along glass garage door wall) ----
for i in range(6):
    # Base
    ell_base = doc.addObject("Part::Box", f"Elliptical_{i}_Base")
    ell_base.Length = 2.5 * FT
    ell_base.Width = 5 * FT
    ell_base.Height = 18 * IN
    ell_base.Placement = App.Placement(
        App.Vector(BW - 5 * FT, 8 * FT + i * 14 * FT, 0),
        App.Rotation()
    )
    ell_base.ViewObject.ShapeColor = (0.18, 0.18, 0.22)

    # Display/handles
    ell_top = doc.addObject("Part::Box", f"Elliptical_{i}_Handles")
    ell_top.Length = 0.5 * FT
    ell_top.Width = 2 * FT
    ell_top.Height = 3.5 * FT
    ell_top.Placement = App.Placement(
        App.Vector(BW - 4.5 * FT, 8 * FT + i * 14 * FT + 1.5 * FT, 18 * IN),
        App.Rotation()
    )
    ell_top.ViewObject.ShapeColor = (0.25, 0.25, 0.28)

# ---- BATTLE ROPES ANCHOR ----
anchor = doc.addObject("Part::Box", "BattleRope_Anchor")
anchor.Length = 1 * FT
anchor.Width = 1 * FT
anchor.Height = 3 * FT
anchor.Placement = App.Placement(
    App.Vector(SC_X + SC_W / 2, BL - 5 * FT, 0),
    App.Rotation()
)
anchor.ViewObject.ShapeColor = (0.40, 0.40, 0.42)

doc.recompute()
doc.saveAs("/tmp/07_sc_equipment.FCStd")
print("✅ 07_sc_equipment.FCStd saved")
