# 01_slab_foundation.py — Louden/Desaro Gymnasium
# Concrete slab + perimeter thickened-edge footings
# Run: freecadcmd 01_slab_foundation.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("Slab_Foundation")

# Main slab: 100' x 100' x 6"
slab = doc.addObject("Part::Box", "Slab")
slab.Length = 100 * FT
slab.Width = 100 * FT
slab.Height = 6 * IN
slab.Placement = App.Placement(App.Vector(0, 0, -6 * IN), App.Rotation())
slab.ViewObject.ShapeColor = (0.72, 0.72, 0.70)

# Perimeter footings: 12" wide x 24" deep (thickened edge)
fw = 12 * IN
fd = 24 * IN
bw = 100 * FT

for name, l, w, x, y in [
    ("Footing_South", bw, fw, 0, 0),
    ("Footing_North", bw, fw, 0, bw - fw),
    ("Footing_West", fw, bw, 0, 0),
    ("Footing_East", fw, bw, bw - fw, 0),
]:
    f = doc.addObject("Part::Box", name)
    f.Length = l
    f.Width = w
    f.Height = fd
    f.Placement = App.Placement(App.Vector(x, y, -fd), App.Rotation())
    f.ViewObject.ShapeColor = (0.65, 0.65, 0.63)

doc.recompute()
doc.saveAs("/tmp/01_slab_foundation.FCStd")
print("✅ 01_slab_foundation.FCStd saved")
