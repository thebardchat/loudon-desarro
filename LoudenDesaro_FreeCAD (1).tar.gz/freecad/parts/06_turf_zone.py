# 06_turf_zone.py — Louden/Desaro Gymnasium
# 40-yard indoor turf strip with yard line markings
# Run: freecadcmd 06_turf_zone.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("Turf_Zone")

BL = 100 * FT
DIVIDER_X = 60 * FT  # Where divider wall sits

# Turf: 15' wide, full 100' length, against the divider wall
TURF_W = 15 * FT
TURF_L = BL
TURF_X = DIVIDER_X - TURF_W - 1 * FT  # 1' gap from divider

# Turf surface
turf = doc.addObject("Part::Box", "Turf_Surface")
turf.Length = TURF_W
turf.Width = TURF_L
turf.Height = 1 * IN
turf.Placement = App.Placement(App.Vector(TURF_X, 0, 0), App.Rotation())
turf.ViewObject.ShapeColor = (0.15, 0.50, 0.18)

# Yard lines every 5 yards (15 feet)
# 40 yards = 120 feet. Building is 100'. So we get ~6.5 five-yard intervals.
# Mark every 5 yards from one end
LINE_W = 2 * IN
yard_interval = 5 * 3 * FT  # 5 yards = 15 feet

line_count = 0
y = 5 * FT  # Start 5' from south edge
while y < TURF_L - 2 * FT:
    line = doc.addObject("Part::Box", f"YardLine_{line_count}")
    line.Length = TURF_W - 1 * FT
    line.Width = LINE_W
    line.Height = 0.5  # Just a surface marking
    line.Placement = App.Placement(
        App.Vector(TURF_X + 0.5 * FT, y, 1 * IN + 0.5),
        App.Rotation()
    )
    line.ViewObject.ShapeColor = (0.92, 0.92, 0.92)
    y += yard_interval
    line_count += 1

# End zone lines (thicker, at each end)
for name, y_pos in [("EndLine_South", 1 * FT), ("EndLine_North", TURF_L - 2 * FT)]:
    el = doc.addObject("Part::Box", name)
    el.Length = TURF_W - 1 * FT
    el.Width = 4 * IN
    el.Height = 0.5
    el.Placement = App.Placement(
        App.Vector(TURF_X + 0.5 * FT, y_pos, 1 * IN + 0.5),
        App.Rotation()
    )
    el.ViewObject.ShapeColor = (0.95, 0.95, 0.95)

# Hash marks (short lines perpendicular to yard lines)
for yl in range(line_count):
    y_base = 5 * FT + yl * yard_interval
    for side in [TURF_X + 3 * FT, TURF_X + TURF_W - 4 * FT]:
        hm = doc.addObject("Part::Box", f"Hash_{yl}_{int(side)}")
        hm.Length = 1 * IN
        hm.Width = 2 * FT
        hm.Height = 0.5
        hm.Placement = App.Placement(
            App.Vector(side, y_base - 1 * FT, 1 * IN + 0.5),
            App.Rotation()
        )
        hm.ViewObject.ShapeColor = (0.92, 0.92, 0.92)

doc.recompute()
doc.saveAs("/tmp/06_turf_zone.FCStd")
print("✅ 06_turf_zone.FCStd saved")
