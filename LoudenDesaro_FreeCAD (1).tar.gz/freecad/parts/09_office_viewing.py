# 09_office_viewing.py — Louden/Desaro Gymnasium
# Office / Parent viewing area (southwest corner)
# Glass wall overlooking the wrestling mat area
# Run: freecadcmd 09_office_viewing.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("Office_Viewing")

OFF_W = 20 * FT   # Width (along X)
OFF_D = 16 * FT   # Depth (along Y)
OFF_H = 10 * FT   # Ceiling height
WALL_T = 4 * IN

# Office floor (warm wood tone)
floor = doc.addObject("Part::Box", "Office_Floor")
floor.Length = OFF_W
floor.Width = OFF_D
floor.Height = 0.5 * IN
floor.Placement = App.Placement(App.Vector(0, 0, 0), App.Rotation())
floor.ViewObject.ShapeColor = (0.72, 0.58, 0.38)

# North wall (solid — separates from mat area at high level)
n_wall = doc.addObject("Part::Box", "Office_Wall_North")
n_wall.Length = OFF_W
n_wall.Width = WALL_T
n_wall.Height = OFF_H
n_wall.Placement = App.Placement(App.Vector(0, OFF_D, 0), App.Rotation())
n_wall.ViewObject.ShapeColor = (0.85, 0.82, 0.78)

# East wall (solid)
e_wall = doc.addObject("Part::Box", "Office_Wall_East")
e_wall.Length = WALL_T
e_wall.Width = OFF_D
e_wall.Height = OFF_H
e_wall.Placement = App.Placement(App.Vector(OFF_W, 0, 0), App.Rotation())
e_wall.ViewObject.ShapeColor = (0.85, 0.82, 0.78)

# Glass viewing wall (north wall — lower portion is glass into mat area)
glass_h = 7 * FT  # Glass from 3' to 10'
glass_sill = 3 * FT  # Sill height

glass = doc.addObject("Part::Box", "Viewing_Glass")
glass.Length = OFF_W - 2 * FT  # Leave frame on sides
glass.Width = 1 * IN
glass.Height = glass_h
glass.Placement = App.Placement(
    App.Vector(1 * FT, OFF_D + 1 * IN, glass_sill),
    App.Rotation()
)
glass.ViewObject.ShapeColor = (0.55, 0.75, 0.85)
glass.ViewObject.Transparency = 60

# Glass frame (gold accent)
frame_top = doc.addObject("Part::Box", "Glass_Frame_Top")
frame_top.Length = OFF_W
frame_top.Width = 2 * IN
frame_top.Height = 2 * IN
frame_top.Placement = App.Placement(
    App.Vector(0, OFF_D, glass_sill + glass_h),
    App.Rotation()
)
frame_top.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

frame_bot = doc.addObject("Part::Box", "Glass_Frame_Bottom")
frame_bot.Length = OFF_W
frame_bot.Width = 2 * IN
frame_bot.Height = 2 * IN
frame_bot.Placement = App.Placement(
    App.Vector(0, OFF_D, glass_sill - 2 * IN),
    App.Rotation()
)
frame_bot.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

# Desk
desk = doc.addObject("Part::Box", "Office_Desk")
desk.Length = 6 * FT
desk.Width = 2.5 * FT
desk.Height = 30 * IN
desk.Placement = App.Placement(App.Vector(2 * FT, 2 * FT, 0), App.Rotation())
desk.ViewObject.ShapeColor = (0.40, 0.30, 0.18)

# Chair
chair = doc.addObject("Part::Box", "Office_Chair")
chair.Length = 2 * FT
chair.Width = 2 * FT
chair.Height = 18 * IN
chair.Placement = App.Placement(App.Vector(4 * FT, 5 * FT, 0), App.Rotation())
chair.ViewObject.ShapeColor = (0.25, 0.25, 0.28)

# Parent seating (viewing bench along glass wall)
for i in range(3):
    bench = doc.addObject("Part::Box", f"Viewing_Bench_{i}")
    bench.Length = 5 * FT
    bench.Width = 1.5 * FT
    bench.Height = 18 * IN
    bench.Placement = App.Placement(
        App.Vector(1 * FT + i * 6 * FT, OFF_D - 3 * FT, 0),
        App.Rotation()
    )
    bench.ViewObject.ShapeColor = (0.30, 0.30, 0.35)

doc.recompute()
doc.saveAs("/tmp/09_office_viewing.FCStd")
print("✅ 09_office_viewing.FCStd saved")
