# 08_glass_garage_doors.py — Louden/Desaro Gymnasium
# Full-height glass garage doors along east wall (S&C side)
# These raise for open-air training
# Run: freecadcmd 08_glass_garage_doors.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("Glass_Garage_Doors")

BW = 100 * FT
BL = 100 * FT
DOOR_H = 14 * FT    # 14 foot tall glass doors
FRAME_W = 3 * IN     # Frame member width
NUM_DOORS = 8
DOOR_W = BL / NUM_DOORS  # Each door panel width

for i in range(NUM_DOORS):
    y_start = i * DOOR_W
    y_center = y_start + DOOR_W / 2

    # Glass panel
    glass = doc.addObject("Part::Box", f"GlassDoor_{i+1}")
    glass.Length = 2 * IN
    glass.Width = DOOR_W - 4 * IN  # Gap for frame
    glass.Height = DOOR_H
    glass.Placement = App.Placement(
        App.Vector(BW - 6 * IN, y_start + 2 * IN, 0),
        App.Rotation()
    )
    glass.ViewObject.ShapeColor = (0.55, 0.75, 0.85)
    glass.ViewObject.Transparency = 65

    # Horizontal frame bars (gold accent) — 4 horizontal dividers
    for h in range(5):
        hbar = doc.addObject("Part::Box", f"GlassDoor_{i+1}_HBar_{h}")
        hbar.Length = FRAME_W
        hbar.Width = DOOR_W - 2 * IN
        hbar.Height = FRAME_W
        hbar.Placement = App.Placement(
            App.Vector(BW - 6 * IN - 0.5 * IN, y_start + 1 * IN, h * DOOR_H / 4),
            App.Rotation()
        )
        hbar.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

    # Vertical frame (left side of each door)
    vbar = doc.addObject("Part::Box", f"GlassDoor_{i+1}_VFrame")
    vbar.Length = FRAME_W
    vbar.Width = FRAME_W
    vbar.Height = DOOR_H
    vbar.Placement = App.Placement(
        App.Vector(BW - 6 * IN - 0.5 * IN, y_start, 0),
        App.Rotation()
    )
    vbar.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

# Final vertical frame (right side of last door)
vbar_end = doc.addObject("Part::Box", "GlassDoor_VFrame_End")
vbar_end.Length = FRAME_W
vbar_end.Width = FRAME_W
vbar_end.Height = DOOR_H
vbar_end.Placement = App.Placement(
    App.Vector(BW - 6 * IN - 0.5 * IN, BL - FRAME_W, 0),
    App.Rotation()
)
vbar_end.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

# Header beam above all doors
header = doc.addObject("Part::Box", "GarageDoor_Header")
header.Length = 8 * IN
header.Width = BL
header.Height = 8 * IN
header.Placement = App.Placement(
    App.Vector(BW - 10 * IN, 0, DOOR_H),
    App.Rotation()
)
header.ViewObject.ShapeColor = (0.30, 0.30, 0.32)

doc.recompute()
doc.saveAs("/tmp/08_glass_garage_doors.FCStd")
print("✅ 08_glass_garage_doors.FCStd saved")
