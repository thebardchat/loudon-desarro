# 04_wrestling_mats.py — Louden/Desaro Gymnasium
# 3 NCAA regulation 42'x42' wrestling mats (training layout)
# NCAA spec: 42'x42' mat, 32' competition circle, 10' inner circle
# Run: freecadcmd 04_wrestling_mats.py

import FreeCAD as App
import Part
import math

FT = 304.8
IN = 25.4

doc = App.newDocument("Wrestling_Mats")

MAT = 42 * FT      # 42 foot mat
MAT_H = 2 * IN     # 2 inch thick (NCAA minimum)
COMP_R = 16 * FT   # 32' competition circle radius
INNER_R = 5 * FT   # 10' inner circle radius
RING_W = 2 * IN     # Circle line width

def make_mat(name, x, y):
    """Create one NCAA regulation wrestling mat with circles."""
    cx = x + MAT / 2  # Center X
    cy = y + MAT / 2  # Center Y

    # Mat base (red)
    base = doc.addObject("Part::Box", f"{name}_Base")
    base.Length = MAT
    base.Width = MAT
    base.Height = MAT_H
    base.Placement = App.Placement(App.Vector(x, y, 0), App.Rotation())
    base.ViewObject.ShapeColor = (0.70, 0.08, 0.12)

    # Competition circle (32' diameter) — gold ring on mat surface
    try:
        outer = Part.makeCylinder(COMP_R, 1, App.Vector(cx, cy, MAT_H))
        inner = Part.makeCylinder(COMP_R - RING_W, 1, App.Vector(cx, cy, MAT_H))
        ring_shape = outer.cut(inner)
        ring = doc.addObject("Part::Feature", f"{name}_CompCircle")
        ring.Shape = ring_shape
        ring.ViewObject.ShapeColor = (0.83, 0.69, 0.22)
    except:
        pass

    # Inner circle (10' diameter) — gold ring
    try:
        outer2 = Part.makeCylinder(INNER_R, 1, App.Vector(cx, cy, MAT_H))
        inner2 = Part.makeCylinder(INNER_R - RING_W, 1, App.Vector(cx, cy, MAT_H))
        ring2_shape = outer2.cut(inner2)
        ring2 = doc.addObject("Part::Feature", f"{name}_InnerCircle")
        ring2.Shape = ring2_shape
        ring2.ViewObject.ShapeColor = (0.83, 0.69, 0.22)
    except:
        pass

    # Center dot (1m / ~3.3' diameter)
    try:
        dot = Part.makeCylinder(1.5 * FT, 1, App.Vector(cx, cy, MAT_H))
        dot_obj = doc.addObject("Part::Feature", f"{name}_CenterDot")
        dot_obj.Shape = dot
        dot_obj.ViewObject.ShapeColor = (0.83, 0.69, 0.22)
    except:
        pass

    # Starting lines (2 lines, 3' long, 10" apart, 1" wide)
    for offset in [-5 * IN, 5 * IN]:
        line = doc.addObject("Part::Box", f"{name}_StartLine")
        line.Length = 3 * FT
        line.Width = 1 * IN
        line.Height = 1
        line.Placement = App.Placement(
            App.Vector(cx - 1.5 * FT, cy + offset, MAT_H),
            App.Rotation()
        )
        line.ViewObject.ShapeColor = (0.1, 0.6, 0.1)

# TRAINING LAYOUT: 2 mats in row + 1 offset
# Mat area is west side of building (0 to ~60')
gap = 3 * FT
border = 3 * FT

make_mat("Mat1_Competition", border, border)
make_mat("Mat2_Competition", border, border + MAT + gap)
make_mat("Mat3_WarmUp", border + MAT + gap, (100 * FT - MAT) / 2)

doc.recompute()
doc.saveAs("/tmp/04_wrestling_mats.FCStd")
print("✅ 04_wrestling_mats.FCStd saved")
