# 10_exterior_site.py — Louden/Desaro Gymnasium
# Parking, entrance doors, signage, exterior site elements
# Run: freecadcmd 10_exterior_site.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("Exterior_Site")

BW = 100 * FT
BL = 100 * FT
BH = 22 * FT

# ---- PARKING LOT (south side) ----
parking = doc.addObject("Part::Box", "Parking_Lot")
parking.Length = 120 * FT
parking.Width = 60 * FT
parking.Height = 4 * IN
parking.Placement = App.Placement(
    App.Vector(-10 * FT, -65 * FT, -6 * IN),
    App.Rotation()
)
parking.ViewObject.ShapeColor = (0.22, 0.22, 0.22)

# Parking stripes (20 spaces)
for i in range(21):
    stripe = doc.addObject("Part::Box", f"ParkingStripe_{i}")
    stripe.Length = 4 * IN
    stripe.Width = 18 * FT
    stripe.Height = 0.5
    stripe.Placement = App.Placement(
        App.Vector(5 * FT + i * 5 * FT, -55 * FT, -2 * IN),
        App.Rotation()
    )
    stripe.ViewObject.ShapeColor = (0.90, 0.90, 0.90)

# Sidewalk (from parking to entrance)
sidewalk = doc.addObject("Part::Box", "Sidewalk")
sidewalk.Length = 20 * FT
sidewalk.Width = 10 * FT
sidewalk.Height = 4 * IN
sidewalk.Placement = App.Placement(
    App.Vector(BW / 2 - 10 * FT, -10 * FT, -4 * IN),
    App.Rotation()
)
sidewalk.ViewObject.ShapeColor = (0.75, 0.75, 0.72)

# ---- MAIN ENTRANCE DOORS (gold accent) ----
# Double door on south facade
for dx in [0, 3.5 * FT]:
    door = doc.addObject("Part::Box", f"EntranceDoor_{int(dx)}")
    door.Length = 3 * FT
    door.Width = 6 * IN
    door.Height = 8 * FT
    door.Placement = App.Placement(
        App.Vector(BW / 2 - 3.5 * FT + dx, -3 * IN, 0),
        App.Rotation()
    )
    door.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

# Door frame
frame = doc.addObject("Part::Box", "Door_Frame")
frame.Length = 8 * FT
frame.Width = 4 * IN
frame.Height = 9 * FT
frame.Placement = App.Placement(
    App.Vector(BW / 2 - 4 * FT, -4 * IN, 0),
    App.Rotation()
)
frame.ViewObject.ShapeColor = (0.20, 0.20, 0.22)

# ---- SIGNAGE ----
# Main sign background (dark panel on south facade)
sign_bg = doc.addObject("Part::Box", "Sign_Background")
sign_bg.Length = 30 * FT
sign_bg.Width = 2 * IN
sign_bg.Height = 5 * FT
sign_bg.Placement = App.Placement(
    App.Vector(BW / 2 - 15 * FT, -4 * IN, BH * 0.55),
    App.Rotation()
)
sign_bg.ViewObject.ShapeColor = (0.08, 0.08, 0.10)

# Gold accent bar under sign
sign_accent = doc.addObject("Part::Box", "Sign_Accent")
sign_accent.Length = 32 * FT
sign_accent.Width = 2 * IN
sign_accent.Height = 1 * IN
sign_accent.Placement = App.Placement(
    App.Vector(BW / 2 - 16 * FT, -5 * IN, BH * 0.55 - 2 * IN),
    App.Rotation()
)
sign_accent.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

# ---- ROLL-UP DOOR (north wall, equipment access) ----
rollup = doc.addObject("Part::Box", "RollUp_Door")
rollup.Length = 14 * FT
rollup.Width = 6 * IN
rollup.Height = 14 * FT
rollup.Placement = App.Placement(
    App.Vector(20 * FT, BL, 0),
    App.Rotation()
)
rollup.ViewObject.ShapeColor = (0.45, 0.45, 0.48)

# ---- EMERGENCY EXIT (west wall) ----
emerg = doc.addObject("Part::Box", "Emergency_Exit")
emerg.Length = 6 * IN
emerg.Width = 3 * FT
emerg.Height = 7 * FT
emerg.Placement = App.Placement(
    App.Vector(-3 * IN, BL / 2, 0),
    App.Rotation()
)
emerg.ViewObject.ShapeColor = (0.80, 0.10, 0.10)

# ---- FLAGPOLE ----
pole = doc.addObject("Part::Box", "Flagpole")
pole.Length = 4 * IN
pole.Width = 4 * IN
pole.Height = 25 * FT
pole.Placement = App.Placement(
    App.Vector(BW / 2 + 20 * FT, -8 * FT, 0),
    App.Rotation()
)
pole.ViewObject.ShapeColor = (0.70, 0.70, 0.72)

doc.recompute()
doc.saveAs("/tmp/10_exterior_site.FCStd")
print("✅ 10_exterior_site.FCStd saved")
