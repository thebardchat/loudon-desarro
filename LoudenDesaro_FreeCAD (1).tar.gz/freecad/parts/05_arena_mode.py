# 05_arena_mode.py — Louden/Desaro Gymnasium
# NCAA Arena configuration: single center mat + retractable bleachers + scoreboard
# Run: freecadcmd 05_arena_mode.py

import FreeCAD as App
import Part

FT = 304.8
IN = 25.4

doc = App.newDocument("Arena_Mode")

MAT = 42 * FT
MAT_H = 2 * IN
BW = 100 * FT
BL = 100 * FT
BH = 22 * FT
ARENA_W = 60 * FT  # Arena zone width (west side)

# ---- SINGLE CENTER COMPETITION MAT ----
mat_x = (ARENA_W - MAT) / 2
mat_y = (BL - MAT) / 2

base = doc.addObject("Part::Box", "Arena_Mat")
base.Length = MAT
base.Width = MAT
base.Height = MAT_H
base.Placement = App.Placement(App.Vector(mat_x, mat_y, 0), App.Rotation())
base.ViewObject.ShapeColor = (0.70, 0.08, 0.12)

# Competition circle
cx = mat_x + MAT / 2
cy = mat_y + MAT / 2
try:
    outer = Part.makeCylinder(16 * FT, 1, App.Vector(cx, cy, MAT_H))
    inner = Part.makeCylinder(16 * FT - 2 * IN, 1, App.Vector(cx, cy, MAT_H))
    ring = doc.addObject("Part::Feature", "Arena_CompCircle")
    ring.Shape = outer.cut(inner)
    ring.ViewObject.ShapeColor = (0.83, 0.69, 0.22)
except:
    pass

# Inner circle
try:
    o2 = Part.makeCylinder(5 * FT, 1, App.Vector(cx, cy, MAT_H))
    i2 = Part.makeCylinder(5 * FT - 2 * IN, 1, App.Vector(cx, cy, MAT_H))
    r2 = doc.addObject("Part::Feature", "Arena_InnerCircle")
    r2.Shape = o2.cut(i2)
    r2.ViewObject.ShapeColor = (0.83, 0.69, 0.22)
except:
    pass

# Center dot
try:
    dot = Part.makeCylinder(1.5 * FT, 1, App.Vector(cx, cy, MAT_H))
    d = doc.addObject("Part::Feature", "Arena_CenterDot")
    d.Shape = dot
    d.ViewObject.ShapeColor = (0.83, 0.69, 0.22)
except:
    pass

# ---- RETRACTABLE BLEACHERS ----
SEAT_H = 16 * IN   # Seat height
SEAT_D = 30 * IN   # Seat depth
ROWS = 6

# West side bleachers (facing east toward mat)
for r in range(ROWS):
    seat = doc.addObject("Part::Box", f"Bleacher_West_{r}")
    seat.Length = 2 * FT           # Depth per row
    seat.Width = ARENA_W - 12 * FT # Length of row
    seat.Height = SEAT_H
    seat.Placement = App.Placement(
        App.Vector(1 * FT + r * 2.5 * FT, 6 * FT, r * SEAT_H + MAT_H),
        App.Rotation()
    )
    seat.ViewObject.ShapeColor = (0.30, 0.30, 0.38)

# South bleachers
for r in range(4):
    seat = doc.addObject("Part::Box", f"Bleacher_South_{r}")
    seat.Length = ARENA_W - 8 * FT
    seat.Width = 2 * FT
    seat.Height = SEAT_H
    seat.Placement = App.Placement(
        App.Vector(4 * FT, 2 * FT + r * 2.5 * FT, r * SEAT_H + MAT_H),
        App.Rotation()
    )
    seat.ViewObject.ShapeColor = (0.30, 0.30, 0.38)

# North bleachers
for r in range(4):
    seat = doc.addObject("Part::Box", f"Bleacher_North_{r}")
    seat.Length = ARENA_W - 8 * FT
    seat.Width = 2 * FT
    seat.Height = SEAT_H
    seat.Placement = App.Placement(
        App.Vector(4 * FT, BL - 4 * FT - r * 2.5 * FT, r * SEAT_H + MAT_H),
        App.Rotation()
    )
    seat.ViewObject.ShapeColor = (0.30, 0.30, 0.38)

# ---- SCOREBOARD (hanging) ----
sb = doc.addObject("Part::Box", "Scoreboard")
sb.Length = 12 * FT
sb.Width = 6 * FT
sb.Height = 4 * FT
sb.Placement = App.Placement(
    App.Vector(cx - 6 * FT, cy - 3 * FT, BH * 0.6),
    App.Rotation()
)
sb.ViewObject.ShapeColor = (0.10, 0.10, 0.12)

# Gold accent bar under scoreboard
accent = doc.addObject("Part::Box", "Scoreboard_Accent")
accent.Length = 13 * FT
accent.Width = 6.5 * FT
accent.Height = 1 * IN
accent.Placement = App.Placement(
    App.Vector(cx - 6.5 * FT, cy - 3.25 * FT, BH * 0.6 - 2 * IN),
    App.Rotation()
)
accent.ViewObject.ShapeColor = (0.83, 0.69, 0.22)

# ---- HEAD TABLE (judges) ----
table = doc.addObject("Part::Box", "HeadTable")
table.Length = 8 * FT
table.Width = 2.5 * FT
table.Height = 30 * IN
table.Placement = App.Placement(
    App.Vector(cx - 4 * FT, mat_y - 5 * FT, 0),
    App.Rotation()
)
table.ViewObject.ShapeColor = (0.45, 0.35, 0.20)

doc.recompute()
doc.saveAs("/tmp/05_arena_mode.FCStd")
print("✅ 05_arena_mode.FCStd saved")
