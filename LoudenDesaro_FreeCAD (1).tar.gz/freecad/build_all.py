#!/usr/bin/env python3
# build_all.py — Louden/Desaro Gymnasium Master Builder
# Runs all part scripts and merges into one master FreeCAD file.
#
# Usage:
#   Build everything:     freecadcmd build_all.py
#   Build single part:    freecadcmd build_all.py 04
#   Build training mode:  freecadcmd build_all.py training
#   Build arena mode:     freecadcmd build_all.py arena
#
# Output: /mnt/shanebrain-raid/shanebrain-core/freecad/LoudenDesaro_Master.FCStd

import FreeCAD as App
import Part
import os
import sys
import importlib.util
import glob

# ============================================================
# CONFIGURATION
# ============================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PARTS_DIR = os.path.join(SCRIPT_DIR, "parts")
OUTPUT_DIR = SCRIPT_DIR
MASTER_FILE = os.path.join(OUTPUT_DIR, "LoudenDesaro_Master.FCStd")
TRAINING_FILE = os.path.join(OUTPUT_DIR, "LoudenDesaro_Training.FCStd")
ARENA_FILE = os.path.join(OUTPUT_DIR, "LoudenDesaro_Arena.FCStd")

# Part definitions: (filename, description, include_in_training, include_in_arena)
PARTS = [
    ("01_slab_foundation.py",    "Concrete Slab + Footings",     True, True),
    ("02_elliptical_shell.py",   "Elliptical Building Shell",    True, True),
    ("03_steel_structure.py",    "Steel Ribs + Tie Beams",       True, True),
    ("04_wrestling_mats.py",     "3 NCAA Wrestling Mats",        True, False),
    ("05_arena_mode.py",         "Arena: Bleachers + Scoreboard",False, True),
    ("06_turf_zone.py",          "40-Yard Indoor Turf",          True, True),
    ("07_sc_equipment.py",       "S&C Equipment",                True, True),
    ("08_glass_garage_doors.py", "Glass Garage Doors",           True, True),
    ("09_office_viewing.py",     "Office + Viewing Area",        True, True),
    ("10_exterior_site.py",      "Exterior Site",                True, True),
]

# ============================================================
# BUILD FUNCTIONS
# ============================================================

def run_part_script(script_path):
    """Execute a part script and return its generated .FCStd path."""
    filename = os.path.basename(script_path)
    part_num = filename.split("_")[0]
    tmp_path = f"/tmp/{part_num}_{filename.replace('.py', '.FCStd')}"

    print(f"  Building: {filename}...", end=" ", flush=True)

    # Load and execute the script
    spec = importlib.util.spec_from_file_location(f"part_{part_num}", script_path)
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
        print("✅")
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

    return tmp_path


def merge_documents(part_files, output_path, label="Master"):
    """Merge multiple .FCStd files into one master document."""
    print(f"\n  Merging into {label}...", flush=True)

    master = App.newDocument("LoudenDesaro")

    for fpath in part_files:
        if fpath is None or not os.path.exists(fpath):
            continue

        part_name = os.path.basename(fpath).replace(".FCStd", "")

        try:
            part_doc = App.openDocument(fpath)
            for obj in part_doc.Objects:
                # Copy each object to master
                new_obj = master.addObject(obj.TypeId, obj.Name)
                if hasattr(obj, "Shape"):
                    new_obj.Shape = obj.Shape.copy()
                elif hasattr(obj, "Length"):
                    for prop in ["Length", "Width", "Height"]:
                        if hasattr(obj, prop):
                            setattr(new_obj, prop, getattr(obj, prop))

                if hasattr(obj, "Placement"):
                    new_obj.Placement = obj.Placement

                # Copy visual properties
                try:
                    if hasattr(obj, "ViewObject") and hasattr(new_obj, "ViewObject"):
                        if hasattr(obj.ViewObject, "ShapeColor"):
                            new_obj.ViewObject.ShapeColor = obj.ViewObject.ShapeColor
                        if hasattr(obj.ViewObject, "Transparency"):
                            new_obj.ViewObject.Transparency = obj.ViewObject.Transparency
                except:
                    pass

            App.closeDocument(part_doc.Name)
        except Exception as e:
            print(f"    ⚠ Could not merge {part_name}: {e}")

    master.recompute()
    master.saveAs(output_path)
    App.closeDocument(master.Name)
    print(f"  ✅ Saved: {output_path}")


def build_all():
    """Build all parts and merge into master."""
    print("=" * 60)
    print("  LOUDEN / DESARO GYMNASIUM — FULL BUILD")
    print("=" * 60)

    part_files = []
    for filename, desc, _, _ in PARTS:
        script = os.path.join(PARTS_DIR, filename)
        if os.path.exists(script):
            result = run_part_script(script)
            part_files.append(result)
        else:
            print(f"  ⚠ Missing: {filename}")
            part_files.append(None)

    merge_documents(part_files, MASTER_FILE, "Master (All Parts)")

    print("\n" + "=" * 60)
    print("  BUILD COMPLETE")
    print(f"  Master: {MASTER_FILE}")
    print("=" * 60)


def build_mode(mode):
    """Build either training or arena configuration."""
    is_training = (mode == "training")
    label = "Training Mode" if is_training else "NCAA Arena Mode"
    output = TRAINING_FILE if is_training else ARENA_FILE

    print(f"\n  Building: {label}")
    print("-" * 40)

    part_files = []
    for filename, desc, in_training, in_arena in PARTS:
        include = in_training if is_training else in_arena
        if not include:
            print(f"  Skipping: {filename} ({desc})")
            continue

        script = os.path.join(PARTS_DIR, filename)
        if os.path.exists(script):
            result = run_part_script(script)
            part_files.append(result)

    merge_documents(part_files, output, label)
    print(f"\n  ✅ {label} saved to: {output}")


def build_single(part_num):
    """Build a single part by number (e.g., '04')."""
    for filename, desc, _, _ in PARTS:
        if filename.startswith(part_num):
            script = os.path.join(PARTS_DIR, filename)
            if os.path.exists(script):
                print(f"\n  Building single part: {desc}")
                run_part_script(script)
                print(f"  ✅ Saved to /tmp/")
            else:
                print(f"  ❌ Script not found: {script}")
            return
    print(f"  ❌ No part matching '{part_num}'")


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__" or True:  # Always run in freecadcmd
    args = sys.argv[1:] if len(sys.argv) > 1 else []

    if not args:
        build_all()
    elif args[0] == "training":
        build_mode("training")
    elif args[0] == "arena":
        build_mode("arena")
    elif args[0].isdigit() or (len(args[0]) == 2 and args[0][0] == "0"):
        build_single(args[0])
    else:
        print("Usage:")
        print("  freecadcmd build_all.py           # Build everything")
        print("  freecadcmd build_all.py training   # Training mode only")
        print("  freecadcmd build_all.py arena      # Arena mode only")
        print("  freecadcmd build_all.py 04         # Single part by number")
