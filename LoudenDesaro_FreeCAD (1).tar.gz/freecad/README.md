# Louden/Desaro Gymnasium — FreeCAD 3D Model

**Location:** Hazel Green, Alabama
**Building:** 10,000 SF Elliptical Pre-Engineered Metal Structure
**Purpose:** Wrestling Training Facility + Transformable NCAA Arena

---

## Quick Start

### Build everything (headless via SSH):
```bash
cd /mnt/shanebrain-raid/shanebrain-core/freecad
freecadcmd build_all.py
```
Output: `LoudenDesaro_Master.FCStd`

### Build Training Mode only:
```bash
freecadcmd build_all.py training
```

### Build NCAA Arena Mode only:
```bash
freecadcmd build_all.py arena
```

### Build a single part (fast test):
```bash
freecadcmd build_all.py 04    # Just the wrestling mats
freecadcmd build_all.py 02    # Just the elliptical shell
```

### View the model:
Open FreeCAD GUI (at Pi with monitor, or transfer .FCStd to Computer A):
```
File > Open > LoudenDesaro_Master.FCStd
View > Standard Views > Isometric
View > Fit All
```

---

## File Structure

```
freecad/
├── build_all.py                    ← Master builder (run this)
├── LoudenDesaro_Master.FCStd       ← Full model (generated)
├── LoudenDesaro_Training.FCStd     ← Training config (generated)
├── LoudenDesaro_Arena.FCStd        ← Arena config (generated)
├── README.md                       ← This file
└── parts/
    ├── 01_slab_foundation.py       ← 6" concrete slab + footings
    ├── 02_elliptical_shell.py      ← Curved walls + roof
    ├── 03_steel_structure.py       ← Steel arch ribs every 20'
    ├── 04_wrestling_mats.py        ← 3 NCAA 42'x42' mats
    ├── 05_arena_mode.py            ← Bleachers + scoreboard
    ├── 06_turf_zone.py             ← 40-yard indoor turf
    ├── 07_sc_equipment.py          ← Power racks, ellipticals, etc.
    ├── 08_glass_garage_doors.py    ← 8 glass garage doors (east wall)
    ├── 09_office_viewing.py        ← Office + glass viewing wall
    └── 10_exterior_site.py         ← Parking, entrance, signage
```

---

## Building Specs

| Feature | Specification |
|---------|--------------|
| Footprint | 100' × 100' (10,000 SF) |
| Shape | Elliptical arch cross-section |
| Peak Height | 22 feet |
| Slab | 6" reinforced concrete, thickened-edge perimeter footings |
| Structure | Steel arch ribs every 20', tie beams |
| East Wall | 8 glass garage doors (full height, raise for open-air) |
| South Facade | Glass curtain wall with gold-accent entrance |

## Interior Layout

| Zone | Location | Size |
|------|----------|------|
| Wrestling Mats (3) | West side | 42'×42' each (NCAA regulation) |
| 40-Yard Turf | Center strip | 15' × 100' |
| Strength & Conditioning | East side | ~40' × 100' |
| Office / Viewing | Southwest corner | 20' × 16' |
| Equipment Storage | Northeast | As needed |

## NCAA Arena Transformation

Training Mode → Arena Mode:
- 3 practice mats retract → 1 center competition mat
- Retractable bleachers deploy on 3 sides
- Scoreboard drops from ceiling
- Head table positions at mat-side

NCAA Minimum: 42'×42' mat, 32' competition circle, 5' safety border, 5' clearance to obstructions.

---

## Contractors

- **Metal Building:** Summer Time Metals (kit + erection)
- **Concrete Slab:** SRM Concrete (6" reinforced)
- **Glass/Windows:** Coach's Window Company

---

*Louden/Desaro Gymnasium — Building Champions in Northern Alabama*
